function increment(selector) {
  // TODO:
}
